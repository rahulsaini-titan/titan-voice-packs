# Titan voice packs

Redistributable CMU Flite English voice data, with original authorship and licences retained. Titan display aliases do not change original voice identity or imply endorsement.

- Nikita = CMU SLT, female English. `Nikita-SLT.flitevox`, standard Flite 2.2 exported CG data.
- Rajesh = CMU AWB, male English. `Rajesh-AWB.flitevox`, standard Flite 2.2 exported CG data.
- Akash = CMU KAL16, compact male diphone English. `Akash-KAL16-source-data.tar.gz` contains original source/data definitions for compilation. It is NOT a loadable CG `.flitevox` file and must not be renamed into one. Titan compiles this data into its native backend.

These files are not Android applications. The Titan app is not published here. Version 0.13's English voices are bundled and enabled offline; uploading these assets does not add an online downloader to that build.

Read FLITE-COPYING.txt and FLITE-COMPONENT-NOTICES.txt. CMU and other component authors retain copyright. The permissive terms allow redistribution with notices, marked modifications, original author names and disclaimers, and no false endorsement. No non-commercial or unclear-licence Piper Hindi models are included in this repository.

Original sources: https://github.com/festvox/flite . Copyright Carnegie Mellon University and component contributors as recorded in the accompanying original notices. Integration modifications are Android adapter/resampling/installation work in Titan, not authorship of these voices. SLT/AWB data was exported using Flite 2.2's voice dumper, with no voice conversion or added audio DSP. KAL16 source/data remains unmodified.

SHA256SUMS.txt identifies the exact files. Verify before use. A file having the same voice name is not necessarily the same version or hash.
